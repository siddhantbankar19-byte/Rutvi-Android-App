const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('electronAPI', {
  saveJsonExport: (data, fileName) => ipcRenderer.invoke('save-json-export', { data, fileName })
});
