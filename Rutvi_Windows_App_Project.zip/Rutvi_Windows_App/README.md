# Rutvi Automation & Controls — Windows

Windows desktop wrapper for the existing Rutvi HTML software.

## Included
- Offline Windows desktop app
- Existing HTML/CSS/JavaScript interface and localStorage data
- Native **Export Data** save dialog
- Installer build and portable EXE build
- Rutvi application icon

## Local developer run
1. Install Node.js 22+.
2. Run `npm install`.
3. Run `npm start`.

## Build Windows EXEs
Run `npm install` and then `npm run dist` on Windows. Output is created in `dist/`.

The included GitHub Actions workflow can build the setup and portable EXEs automatically on a Windows runner.
