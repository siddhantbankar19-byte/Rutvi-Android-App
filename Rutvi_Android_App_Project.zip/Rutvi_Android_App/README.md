# Rutvi Automation & Controls — Android App

This project wraps the supplied self-contained HTML software in an Android WebView.

## App configuration
- App name: **Rutvi Automation & Controls**
- Package: `com.rutviautomation.controls`
- Version: `1.0.0`
- Minimum Android: Android 7.0 (API 24)
- Target/compile SDK: API 35
- Main HTML: `app/src/main/assets/index.html`
- Offline operation: supported because the supplied HTML has no external web dependencies.
- Persistent data: the original HTML's `localStorage` logic is retained.
- Export Data: patched to use Android's native **Save As** file picker.

## Build with Android Studio
Open this folder in a current Android Studio installation and choose **Build > Build APK(s)**.

## Build automatically with GitHub Actions
Push this folder to a GitHub repository. The included `.github/workflows/build-apk.yml` workflow builds a debug APK and uploads it as an Actions artifact named `Rutvi-Automation-Controls-APK`.

## Important data note
Uninstalling the app or clearing its storage removes WebView local app data. Use **Export Data** periodically for backup.
